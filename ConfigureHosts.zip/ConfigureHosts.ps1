function InstallWVDAgent {
    param
    (    
        [Parameter(Mandatory = $true)]
        [string]$HostPoolName,

        [Parameter(Mandatory = $true)]
        [string]$RegistrationInfoToken,

        [Parameter(Mandatory = $false)]
        [string]$SessionHostConfigurationLastUpdateTime = "",

        [Parameter(Mandatory = $false)]
        [bool]$EnableVerboseMsiLogging = $false
    )

    $ErrorActionPreference = "stop"
    $env:computername
    $temppath = "c:\temp"
    $transcriptLogging = "$temppath\regAvd_$env:computername.log"
    $rootFolder = "C:\AVDHost\"
    $avdAgentInstaller = $rootFolder+"WVD-Agent.msi"
    $avdBootLoaderInstaller = $rootFolder+"WVD-BootLoader.msi"
    mkdir $temppath -Force

    ##agents to download
    $files = @(
        @{url = "https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrmXv"; path = $avdAgentInstaller}
        @{url = "https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrxrH"; path = $avdBootLoaderInstaller}
    )

    foreach ($file in $files ) {
    $i += 1
    $uriwithblob = $file.url
    $local = $file.path
    Start-Job {$ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -Uri $using:uriwithblob  -Method Get -OutFile $using:local} -Name "scriptjob$i"   
    }
    do {
    $ii += 1
    if (Get-Job -State Running) { $Stoploop = $true;Start-Sleep -Seconds 20 } else {$Stoploop = $false}
    Write-Output "Count $ii, still running jobs.."  
    }
    While ($Stoploop -eq $true)

    ##start transcript logging
    Start-Transcript -Path $transcriptLogging
    #Install the WVD Agent
    $return = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $avdAgentInstaller", "/quiet", "/qn", "/norestart", "/passive", "REGISTRATIONTOKEN=$RegistrationInfoToken", "/l* C:\Users\AgentInstall.txt" -Wait -PassThru
    if (!($return.ExitCode -eq 0 -or $return.ExitCode -eq 3010)) {Write-Error "Error $($return.ExitCode). Check logfiles for Error"}
    #Wait to ensure WVD Agent has enough time to finish
    Start-sleep 30
    #Install the WVD Bootloader
    $return = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $avdBootLoaderInstaller", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentBootLoaderInstall.txt" -Wait -PassThru
    if (!($return.ExitCode -eq 0 -or $return.ExitCode -eq 3010)) {Write-Error "Error $($return.ExitCode). Check logfiles for Error"}
    ##stop transcript logging
    Stop-Transcript
}
