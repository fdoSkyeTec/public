function InstallWVDAgent {
    param
    (    
        [Parameter(Mandatory = $true)]
        [string]$HostPoolName,

        [Parameter(Mandatory = $true)]
        [string]$RegistrationInfoToken,

        [Parameter(Mandatory = $false)]
        [string]$SessionHostConfigurationLastUpdateTime = "",

        [Parameter(Mandatory = $false)]
        [bool]$EnableVerboseMsiLogging = $false
    )

    $ErrorActionPreference = "stop"
    $env:computername
    $temppath = "c:\temp"
    $transcriptLogging = "$temppath\regAvd_$env:computername.log"
    $rootFolder = "C:\Packages\Plugins\"
    $avdAgentInstaller = $rootFolder+"WVD-Agent.msi"
    $avdBootLoaderInstaller = $rootFolder+"WVD-BootLoader.msi"
    mkdir $temppath -Force

    ##start transcript logging
    Start-Transcript -Path $transcriptLogging
    #Install the WVD Agent
    $return = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $avdAgentInstaller", "/quiet", "/qn", "/norestart", "/passive", "REGISTRATIONTOKEN=$RegistrationInfoToken", "/l* C:\Users\AgentInstall.txt" -Wait -PassThru
    if (!($return.ExitCode -eq 0 -or $return.ExitCode -eq 3010)) {Write-Error "Error $($return.ExitCode). Check logfiles for Error"}
    #Wait to ensure WVD Agent has enough time to finish
    Start-sleep 30
    #Install the WVD Bootloader
    $return = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $avdBootLoaderInstaller", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentBootLoaderInstall.txt" -Wait -PassThru
    if (!($return.ExitCode -eq 0 -or $return.ExitCode -eq 3010)) {Write-Error "Error $($return.ExitCode). Check logfiles for Error"}
    ##stop transcript logging
    Stop-Transcript
}
